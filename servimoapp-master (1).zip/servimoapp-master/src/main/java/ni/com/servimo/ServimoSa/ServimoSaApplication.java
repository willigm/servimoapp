package ni.com.servimo.ServimoSa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServimoSaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServimoSaApplication.class, args);
	}

}
