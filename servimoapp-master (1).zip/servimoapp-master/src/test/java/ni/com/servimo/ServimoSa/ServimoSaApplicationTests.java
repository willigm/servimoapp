package ni.com.servimo.ServimoSa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServimoSaApplicationTests {

	@Test
	void contextLoads() {
	}

}
